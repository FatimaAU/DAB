﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace PersonkartotekDocumentDB.Models
{
    public class City
    {
        public string CityName { get; set; }
        public string ZipCode { get; set; }
    }
}